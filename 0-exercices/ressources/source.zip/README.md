# Documentation 

---

## Installation de l'environnement de travail

1. [Téléchargez et installez Node (uniquement si vous ne l'avez pas sur votre machine)](https://nodejs.org/en/download)

Les paquets suivantes sont déjà installées et visibles dans le fichier package.json :

- eslint : vérification de la syntaxe de JS et des règles de bonne pratiques dans le codage
- esbuild : compiler le code JS écrit avec les derniers standards du langage pour qu'il puisse être comptabile avec tous les navigateurs
- cypress: écrire les tests fonctionnels
- cors-anywhere : un proxy (intermédiaire) qui empêche le blocage par les navigateurs des requêtes envoyées en local vers les APIs externes
- jquery : librairie JavaScript, une façade qui permet de faire les mêmes choses que le langage natif mais plus rapidement et compatible avec tous les navigateurs
- rss-to-json : parser du XML en JSON

---

### Installation et lancement de l'application

2. Ouvrir un terminal et se placer à la racine du projet (là ou il y a le fichier package.json et les autres dossiers css, html, etc) et exécutez les commandes suivantes
- `npm install`

3. Ouvrir un autre terminal et toujours à la racine du projet, exécutez la commande suivante
- `npm run proxy`

4. Depuis VSCode, ouvrir le fichier src/html/index.html et le lancer avec l'extension VSCode Live Server (Go live en bas à droite). Si vous n'avez pas l'extension Live Server, vous pouvez le télécharger depuis les extensions de VSCode.

---
<!-- 
## Lancement des vos tests fonctionnelles avec Cypress

4. Lancer via live server, le fichier index.html présent dans le dossier src/html/index.html, normalement votre application sera lancé sur http://localhost:5500 . Si le port par défaut n'est pas 5500 mais un autre comme par exemple 5501, veuillez reporter cette modification dans le fichier src/cypress.config.js SVP

5. Ouvrir un autre terminal et toujours à la racine et exécutez la commande suivante 
- `npm run e2e`
PS : une fenetre de sécurité de votre OS apparaitra pour vous demander donner les droits nécessaires Cypress, veuillez acceptez SVP.  -->