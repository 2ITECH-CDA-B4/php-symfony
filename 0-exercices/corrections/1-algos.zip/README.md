# Documentation

## Installation

- `composer install`

## Lancer les tests

- `composer run tests`