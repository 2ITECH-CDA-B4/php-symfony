# Installation et lancement

Depuis la racine du projet :

1. `composer install`
2. Modifiez le ***.env*** pour les informations de la base de données
3. `php bin/console doctrine:schema:update --force`
4. `php bin/console doctrine:fixtures:load`
5. `symfony serve:start`
6. `Allez sur le lien http://localhost:8000/hotel`
PS : c'est possible que le port soit différent de 8000